#pragma once

struct MyStruct {//this is how you define a structure, they are like objects but everything is public and there are no methods. We call this a composite (array is a compsite as is union)
	int v1;
	float v2;
	int* ptr1;
};


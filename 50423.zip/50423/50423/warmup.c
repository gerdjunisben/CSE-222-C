#include <stdio.h>
/*
int main(int argc, char* argv[])
{
	float x = 100;
	float* p = &x;
	*p = 99;
	printf("%f\n", x);

	int array[] = { 1,3,5,7 };
	int* p1 = array;

	for (int i = 0; i < 4; i++)
	{
		*(p1 + i) = *(p1 + i) + 1;
	}

	for (int i = 0; i < 4; i++)
	{
		printf("%d ", *(p1 + i));
	}

	return 0;
}*/
#include "Structure.h"
#include <stdio.h>

/*
int main(int argc, char* argv[])
{
	struct MyStruct s1;//this is how you create a structure, make sure to include the header file with the definition
	s1.v1 = 10;//use . to access vars
	s1.v2 = 20.0;

	struct MyStruct* s2;//this is a structure pointer
	s2 = (struct MyStruct*)malloc(sizeof(struct MyStruct));//allocates memory of the size of MyStruct and returns a pointer to it
	s2->v1 = 12;//use the arrow operator to access data in a stucture pointer
	s2->v2 = 8.8;
	free(s2);



	
	return 0;
}*/
#pragma once
extern double calculateDistance(double x0, double y0, double x1, double y1);
extern int findGreatest(int x, int y, int z);
extern int findSmallest(int x, int y, int z);

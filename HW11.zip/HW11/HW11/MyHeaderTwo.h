#pragma once
#include <stdbool.h>
extern bool isRightTriangle(double x0, double y0, double x1, double y1, double x2, double y2);
extern bool straightLine(double x0, double y0, double x1, double y1, double x2, double y2);
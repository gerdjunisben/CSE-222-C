#pragma once

extern void swapNums(int x, int y);

#define MYCONST 47//you can define functions too, these are called macros

